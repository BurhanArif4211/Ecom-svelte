<?php
// Empty file - no frontend functionality